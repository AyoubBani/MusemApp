<?php 
$con = mysqli_connect("localhost","root","","pfe2");
//  $mysqli = new mysqli('localhost','root','','pfe2');
  
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}else{  
$sql="SELECT o.code_qr, o.oeuvre_name, m.url, a.artiste_name  FROM oeuvre o, media m , artiste a  WHERE o.oeuvre_id=m.oeuvre_id AND o.artiste_id=a.artiste_id and m.media_type='image'";
mysqli_set_charset($con,"utf8");
$result = $con->query($sql);
if ($result->num_rows > 0){
while($row = $result->fetch_assoc()) $output[]=$row;	
		print(json_encode($output));		
	 
	//print(json_encode($flag));
	//mysqli_close($con);    
	$con->close();		
	}else{
		echo 'no data found !!!';
		$con->close();		
	} 
}
 ?>