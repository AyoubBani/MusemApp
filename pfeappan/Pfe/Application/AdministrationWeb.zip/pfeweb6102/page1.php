

<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Administration</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1">	 
	  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>	 
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>    
    <link rel="stylesheet" href="css/normalize.css">    
        <link rel="stylesheet" href="css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    
    
    
  </head>



  <body>
<div class="container">
    <div class="form">
      
      <ul class="tab-group">
        <li class="tab active"><a href="#signup">Nouveau Artiste</a></li>
        <li class="tab"><a href="#login">Nouvelle Œuvre</a></li>
        
      </ul>
      
      <div class="tab-content">
        <div id="signup">   
          <h1>Ajouter un Artiste</h1>
          
          <form action="nvartiste.php" method="post">
                    
          <div class="field-wrap">
            <label>
              Nom de l'Artiste<span class="req">*</span>
            </label>
            <input type="text" name="nom" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Description<span class="req">*</span>
            </label>
            <input type="text" name="desc" required autocomplete="off"/>
          </div>
          
          <button type="submit" class="button button-block"/>Ajouter</button>
          
          </form>

        </div>
        
        <div id="login">   
          <h1>Ajouter une Œuvre</h1>
          
          <form action="nvouevre.php" method="post">
		  
          <div class="field-wrap">
              <label>
                Code Qr<span class="req">*</span>
              </label>
              <input type="text" name="codeqr" required autocomplete="off" />
            </div>
			
			<div class="field-wrap">
              <label>
                Nom de L'œuvre<span class="req">*</span>
              </label>
              <input type="text" name="oeuvrenm" required autocomplete="off" />
            </div>
			
			<div class="field-wrap">
              <label>
                Description de l'œuvre<span class="req">*</span>
              </label>
              <input type="text" name="oeuvredesc" required autocomplete="off" />
            </div>
			
			<div class="field-wrap">
              <label>
                Emplacement<span class="req">*</span>
              </label>
              <input type="text"  name="emp" required autocomplete="off" />
            </div>
			
	

<div class="top-row">
            <div class="field-wrap">
              <label>
                Artiste ID
              </label>
              <input type="text" name="artid" required autocomplete="off" />
            </div>
        
            <div class="field-wrap">
              <label>
                Type ID<span class="req">*</span>
              </label>
              <input type="text" name="typeid" required autocomplete="off"/>
            </div>
			
			
          </div>	
			
				
          
          <p class="forgot"><a href="#" data-toggle="modal" data-target="#myModal">Ajouter Media</a></p>		  
          
          <button class="button button-block"/>Ajouter</button>
          
          </form>

        </div>
        					
		
		
      </div><!-- tab-content -->
      
</div> <!-- /form -->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" align="center">Ajouter Media</h4>
      </div>
      <div class="modal-body">     		
		<div align="center">     
		<div class="form">
		<div id="login">   
		<form method="POST" action="nvmedia.php">
		
		<div class="field-wrap">
              <label>
                Type de Media:<span class="req">*</span>
              </label>
              <input type="text" name="mediatp" required autocomplete="off" />
            </div>
			
		<div class="field-wrap">
              <label>
                Œuvre ID<span class="req">*</span>
              </label>
              <input type="text" name="ovrid" required autocomplete="off" />
            </div>
			
		<div class="field-wrap">
              <label>
                URL<span class="req">*</span>
              </label>
              <input type="text" name="url" required autocomplete="off" />
            </div>
				
		
		<button type="submit" class="button button-block"/>Ajouter</button>
		</form>
		</div>
		</div>
		</div>
		
      </div>
      
    </div>

  </div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script src="js/index.js"></script>   
</div>       
  </body>
</html>
<?php
error_reporting(0);
if(isset($_GET["art"])){
	if($_GET["art"]=="succ"){
		$_GET["art"]="";
		echo "<script>".'alert("Vous avez ajouter un nouveau artiste") '."</script>";		
		header('location: index.php');
	} 
}
if(isset($_GET["ouv"])){
	if($_GET["ouv"]=="succ"){
		$_GET["ouv"]="";		
		echo "<script>".'alert("Vous avez ajouter un nouveau oeuvre") '."</script>";		
		header('location: index.php');
	}
	if($_GET["ouv"]=="err"){
		$_GET["ouv"]="";		
		echo "<script>".'alert("Vous avez entrer un ID Invalid") '."</script>";		
		header('location: index.php');
	}
}

if(isset($_GET["med"])){
	if($_GET["med"]=="succ"){
		$_GET["med"]="";		
		echo "<script>".'alert("Vous avez ajouter un nouveau Media") '."</script>";		
		header('location: index.php');
	}
	if($_GET["med"]=="err"){
		$_GET["med"]="";		
		echo "<script>".'alert("Vous avez entrer un ID Invalid") '."</script>";		
		header('location: index.php');
	}
}
?>