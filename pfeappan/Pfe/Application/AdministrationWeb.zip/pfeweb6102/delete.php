<?php
$mysqli = new mysqli('localhost','root','','pfe_scann');

$x= " SELECT oeuvre_id from oeuvre where artiste_id ='".$_REQUEST['data']."'  ";

$y=$mysqli->query($x);
$row=mysqli_fetch_row($y);
//echo $row[0];
echo $mysqli->error;

$sql2="DELETE FROM media 
where oeuvre_id='$row[0]' ";
$res2=$mysqli->query($sql2);

$sql3="DELETE FROM oeuvre 
where artiste_id ='".$_REQUEST['data']."' ";
$res3=$mysqli->query($sql3);

$sql4="DELETE FROM artiste 
where artiste_id ='".$_REQUEST['data']."' ";
$res4=$mysqli->query($sql4);


echo $mysqli->error;
if($res2 and $res3 and $res4 )
{
header('location:page2.php');
}
?> 
