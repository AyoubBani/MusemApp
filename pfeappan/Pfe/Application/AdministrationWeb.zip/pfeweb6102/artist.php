        
          <?php 
          $bd=new PDO("mysql:host=localhost;dbname=pfe2;charset=utf8","root",""); 
          $req= " select * from artist ";
          $res=$dd->query($req);
           while ($row=mysqli_fetch_row()) {?>
           	
<table>
	
<th>nom</th>
<th>prenom</th>
<th>description</th>

<tr>
	
<td><?php echo $row[1] ?></td>
<td><?php echo $row[2] ?></td>
<td><?php echo $row[3] ?></td>

</tr>
</table>

   
         <?php } ?>
?>
    