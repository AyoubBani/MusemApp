<?php
if(isset($_POST["codeqr"])&&isset($_POST["oeuvrenm"])&&isset($_POST["oeuvredesc"])&&isset($_POST["emp"])&&isset($_POST["artid"])&&isset($_POST["typeid"])){
try{
$bd=new PDO("mysql:host=localhost;dbname=pfe2;charset=utf8","root",""); 	 	 	 	 	 	
$req=$bd->prepare("insert into oeuvre(code_qr, oeuvre_name, oeuvre_description, emplacement, type_id, artiste_id) values(?, ?, ?, ?, ?, ?)");
$req->BindParam(1,$_POST["codeqr"]);
$req->BindParam(2,$_POST["oeuvrenm"]);
$req->BindParam(3,$_POST["oeuvredesc"]);
$req->BindParam(4,$_POST["emp"]);
$req->BindParam(5,$_POST["typeid"]);
$req->BindParam(6,$_POST["artid"]);
$req->execute();
if($req->rowCount()==0) throw new Exception();
header('location: page1.php?ouv=succ');
}
catch(Exception $e){	
 header('location: page1.php?ouv=err');
	// echo 'Error: '.$e->getMessage();
}
	
}

?>