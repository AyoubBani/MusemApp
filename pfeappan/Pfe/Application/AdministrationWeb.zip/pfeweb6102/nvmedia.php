<?php
if(isset($_POST["mediatp"])&&isset($_POST["ovrid"])&&isset($_POST["url"])){
try{
$bd=new PDO("mysql:host=localhost;dbname=pfe2;charset=utf8","root",""); 	
$req=$bd->prepare("insert into media(media_type, url,oeuvre_id) values(?,?,?)");
$req->BindParam(1,$_POST["mediatp"]);
$req->BindParam(2,$_POST["url"]);
$req->BindParam(3,$_POST["ovrid"]);
$req->execute();
if($req->rowCount()==0) throw new Exception();
header('location: index.php?med=succ');
}catch(Exception $e){
	header('location: index.php?med=err');
	echo 'Error: '.$e->getMessage();
}
	
}

?>