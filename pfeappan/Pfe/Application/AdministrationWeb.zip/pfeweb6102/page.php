<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Administration</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1">	 
	  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>	 
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>    
    <link rel="stylesheet" href="css/normalize.css">    
        <link rel="stylesheet" href="css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    
    
    
  </head>



  <body>
 


  


   
<div class="container">
<h1>gestion de l'application </h1>
<img src="logo.PNG">
<br><br><a class="ghost-button" href="page1.php"><div class="txt">Ajouter</div></a><br><br><br> <a class="ghost-button-de" href="page2.php"><div class="cons">Consulter</div></a><br><br><br> <a class="ghost-button-de" href="index.php"><div class="dec">Deconnexion</div></a>





</div>
</body>

</html>