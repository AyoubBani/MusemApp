<?php

$mysqli = new mysqli('localhost','root','','pfe_scann');


?>
