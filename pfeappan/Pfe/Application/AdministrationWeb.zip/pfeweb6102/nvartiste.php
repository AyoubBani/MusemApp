<?php
if(isset($_POST["nom"])&&isset($_POST["desc"])){
try{
$bd=new PDO("mysql:host=localhost;dbname=pfe2;charset=utf8","root",""); 	
$req=$bd->prepare("insert into artiste(artiste_name, artiste_description) values(?,?)");
$req->BindParam(1,$_POST["nom"]);
$req->BindParam(2,$_POST["desc"]);
$req->execute();
header('location: index.php?art=succ');
}catch(Exception $e){
	
	echo 'Error: '.$e->getMessage();
}
	
}

?>