<?php 


session_start();
if (isset($_POST['submit'])) {
  # code...

  $login=$_POST['login'];
  $mp=$_POST['mp'];
  if ($login=='admin' and $mp=='admin') {
    # code...
   header('location:page.php');



 } 
else {
    header('location:index.php');
  } 
  }?>