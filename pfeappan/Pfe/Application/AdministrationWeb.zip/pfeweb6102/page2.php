<!DOCTYPE html>
<html >
  <head>
     <meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1"> 
    <title>Administration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">   
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>   
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>    
    <link rel="stylesheet" href="css/normalize.css">    
        <link rel="stylesheet" href="css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    
    
    
  </head>



  <body>
<div >
    <div >
      
      <ul class="tab-group">
        <li class="tab active"><a href="#signup">la liste des artictes</a></li>
        <li class="tab"><a href="#login">la liste des Oeuvres </a></li>
        
      </ul>
      
      <div class="tab-content">
        <div id="signup">   
          
    <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
 
   <thead  >
   <tr bgcolor=" #179b77" >
      
       <th>NOM</th>
       <th>DESRIPTION</th>
       <th>ACTION</th>
</tr>                               
</thead>
 <h1>Liste des artistes</h1>
<tbody >
 <?php 
   session_start();
   header('Content-Type: text/html; charset=Windows-1252');
   //include 'connection.php';
   $mysqli = new mysqli('localhost','root','','pfe_scann');
   $req="select * from artiste";
   $res=$mysqli->query($req);
   //$mysqli->error;
  // $row=mysqli_fetch_array($res);
   while ($row=mysqli_fetch_row($res)) {?>
   <tr>
  <td><?php echo $row[1]; ?></td>
  <td><?php echo $row[2]; ?></td>

  
<?php echo "<td><a  class= 'delbutton'  href=\"delete.php?data=".$row[0]."\">supprimer</a></td>"; ?>
</tr>
<?php }
 ?>
 </tbody>
     </table>  

        </div>
        
        <div id="login">   
        
    <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
 
   <thead  >
   <tr bgcolor="#179b77" >
      
       <th>code qr</th>
       <th>nom</th>
       <th>descrption</th>
       <th>musee</th>
       <th>type</th>
       <th>supprimer</th>
</tr>                               
</thead>
 <h1>Liste des Oeuvres</h1>
<tbody >
 <?php 
   //session_start();
   //include 'connection.php';
   $mysqli = new mysqli('localhost','root','','pfe_scann');
   $req="select * from oeuvre";
   $res=$mysqli->query($req);
   //$mysqli->error;
  // $row=mysqli_fetch_array($res);
   while ($row=mysqli_fetch_array($res)) {?>
   <tr>
  <td><?php echo $row['code_qr']; ?></td>
  <td><?php echo $row['oeuvre_name']; ?></td>
  <td><?php echo $row['oeuvre_description']; ?></td>
  <td><?php echo $row['musee_id']; ?></td>
  <td><?php echo $row['type_id']; ?></td>

<?php echo "<td><a  class= 'delbuttonO'  href=\"deleteO.php?data=".$row[0]."\">supprimer</a></td>"; ?>

</tr>
<?php }
 ?>
 </tbody>
     </table>  

        </div>
                  
    
    
      </div><!-- tab-content -->
      
</div> <!-- /form -->


    
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script src="js/index.js"></script>   
</div>       
  </body>
</html>


<script type="text/javascript">
$(function() {

$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("artiste_id");

//Built a url to send
//var info = 'accNo=' + del_id;
 if(confirm("voulez vous vraiment supprimer cet ARTISTE ====> la suppression de l'artiste va générer la suppression automatique  de toutes ses oeuvres ?"))
      {

 $.ajax({
   type: "GET",
   url: "delete.php",
   data: info,
   success: function(){
   
   }
 });

 }

return false;

});

});
</script>


<script type="text/javascript">
$(function() {

$(".delbuttonO").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("artiste_id");

//Built a url to send
//var info = 'accNo=' + del_id;
 if(confirm("voulez vous vraiment supprimer cette oeuvre ?"))
      {

 $.ajax({
   type: "GET",
   url: "deleteO.php",
   data: info,
   success: function(){
   
   }
 });

 }

return false;

});

});
</script>