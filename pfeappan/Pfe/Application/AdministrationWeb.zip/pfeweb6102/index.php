<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Administration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">   
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>   
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>    
    <link rel="stylesheet" href="css/normalize.css">    
        <link rel="stylesheet" href="css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    
    
    
  </head>



  <body>
<div class="container">
    <div class="form">
      
      
      
      <div class="tab-content">
        <div id="signup">   
          <h1>Connexion </h1>
          
          <form action="logadmin.php" method="post">
                    
          <div class="field-wrap">
            <label>
             login<span class="req">*</span>
            </label>
            <input type="text" name="login" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Mot de passe<span class="req">*</span>
            </label>
            <input type="password" name="mp" required autocomplete="off"/>
          </div>
          
          <button type="submit"  name="submit"  class="button button-block"/>Connexion</button>
          
          </form>

        </div>
        
       
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script src="js/index.js"></script>   
</div>       
  </body>
</html>